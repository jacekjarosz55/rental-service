var indexSectionsWithContent =
{
  0: "acdefgiklmnprsuy",
  1: "cr",
  2: "cmru",
  3: "acdfgmprsu",
  4: "cdefiklmnpy"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables"
};

