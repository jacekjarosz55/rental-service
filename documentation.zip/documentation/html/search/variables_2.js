var searchData=
[
  ['email_0',['email',['../structClient.html#a4d530203829b1520ca95f69706feb453',1,'Client']]]
];
