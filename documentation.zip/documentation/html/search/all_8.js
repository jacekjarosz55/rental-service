var searchData=
[
  ['last_5fname_0',['last_name',['../structClient.html#a728545636414da517145a91f54155275',1,'Client']]]
];
