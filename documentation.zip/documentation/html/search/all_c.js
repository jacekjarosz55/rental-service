var searchData=
[
  ['remove_5fcar_5fby_5fid_0',['remove_car_by_id',['../carlist_8h.html#aa638fc4e9ee2581c446cef2e286a51a3',1,'carlist.c']]],
  ['remove_5fclient_5fby_5fid_1',['remove_client_by_id',['../clientlist_8h.html#a6d83a30ef481e5ff0fadefe86a97eb6f',1,'clientlist.c']]],
  ['remove_5frent_5fby_5fid_2',['remove_rent_by_id',['../rentlist_8h.html#af125daa5b2b874347f710f4894152e4a',1,'rentlist.c']]],
  ['removecar_3',['removeCar',['../main_8c.html#a1eb2fb9ba77986c2fddcb307bb6ddcc1',1,'main.c']]],
  ['removeclient_4',['removeClient',['../main_8c.html#ada871eb67df3eda97251d4b9dca57468',1,'main.c']]],
  ['removerent_5',['removeRent',['../main_8c.html#a1c0ec2810a0cfe76fbc840f0db0769d4',1,'main.c']]],
  ['rent_6',['Rent',['../structRent.html',1,'']]],
  ['rent_2eh_7',['rent.h',['../rent_8h.html',1,'']]],
  ['rent_5ffinish_8',['rent_finish',['../rent_8h.html#a2e4c22e748b5161da7f8783b25e936e6',1,'rent.c']]],
  ['rent_5flist_5fnew_5ffrom_5ffile_9',['rent_list_new_from_file',['../rentlist_8h.html#adfd293ae458e72d8b66a9e70ca7f6f78',1,'rentlist.c']]],
  ['rent_5flist_5fsave_5fto_5ffile_10',['rent_list_save_to_file',['../rentlist_8h.html#afc4cdeaba1818bb3c8c0e69ba6f15232',1,'rentlist.c']]],
  ['rentdetails_11',['rentDetails',['../main_8c.html#a1da5ec7d1045bec81cd8f294f02b3434',1,'main.c']]],
  ['rentlist_2eh_12',['rentlist.h',['../rentlist_8h.html',1,'']]],
  ['rentnode_13',['RentNode',['../structRentNode.html',1,'']]]
];
