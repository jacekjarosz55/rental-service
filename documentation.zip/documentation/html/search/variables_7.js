var searchData=
[
  ['make_0',['make',['../structCar.html#ab4e5da1932715e9e53148c6367a883d2',1,'Car']]],
  ['model_1',['model',['../structCar.html#ac930d200b892372999f4734387dfa142',1,'Car']]]
];
